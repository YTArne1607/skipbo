﻿using SkipBo.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SkipBo
{
    public partial class uiFormSkipBo : Form
    {
        bool dragFlag = false;
        //bool allowDrag = true;
        Point cardStartLocation = new Point();
        int[] ablageStapelCount = new int[4];
        Tuple<Bitmap, int>[] cardCounts = new Tuple<Bitmap, int>[13];
        Control[] cardBuffer = new Control[60];
        Point[] handCardsStartLocation = new Point[5];
        Random randomGlobal = new Random();
        int[] zIndex = new int[56];
        int[] acceptedNumsInAblageStapel = new int[12];
        int currentCardNumber = 0;
        bool firstRun = true;

        public uiFormSkipBo()
        {
            InitializeComponent();

            cardStartLocation = uiPictureBoxHauptStapel.Location;

            for (int k = 0; k < 60; k++)
            {
                cardBuffer[k] = new PictureBox()
                {
                    Location = new Point(274, 360),
                    BackgroundImageLayout = ImageLayout.Zoom,
                    BackColor = Color.Transparent,
                    Size = new Size(60, 85)
                };

                cardBuffer[k].MouseDown += OnPictureBoxHauptStapelMouseDown;
                cardBuffer[k].MouseUp += OnPictureBoxHauptStapelMouseUp;

            }

            CardSpread();

            int mainCardStaple = randomGlobal.Next(0, 12 + 1);
            uiPictureBoxHauptStapel.BackgroundImage = cardCounts[mainCardStaple].Item1;
            uiPictureBoxHauptStapel.Tag = cardCounts[mainCardStaple].Item2;

        }

        private async void GenerateCard(int startPosition)
        {
            while (cardBuffer[startPosition].Location.X < handCardsStartLocation[startPosition].X)
            {
                cardBuffer[startPosition].Location = new Point(cardBuffer[startPosition].Location.X + 12, cardBuffer[startPosition].Location.Y);
                await Task.Delay(10);
            }
        }
        private async void CardSpread()
        {

            for (int i = 0; i < 13; i++)
            {
                cardCounts[i] = new Tuple<Bitmap, int>(new Bitmap(Directory.GetCurrentDirectory() + "\\Resources\\Card " + (i + 1) + ".jpg"), i);
            }



            int handCardDistance = 0;
            handCardDistance += 48;
            cardBuffer[0].BackgroundImage = cardCounts[0].Item1;
            cardBuffer[0].Tag = cardCounts[0].Item2;
            this.Controls.Add(cardBuffer[0]);
            handCardsStartLocation[0] = new Point((cardBuffer[0].Location.X - 48) + handCardDistance, cardBuffer[0].Location.Y);
            cardBuffer[0].Location = new Point(120, 360);
            cardBuffer[0].AccessibleName = 0.ToString();
            GenerateCard(0);

            handCardDistance += 48;
            cardBuffer[1].BackgroundImage = cardCounts[12].Item1;
            cardBuffer[1].Tag = cardCounts[12].Item2;
            this.Controls.Add(cardBuffer[1]);
            handCardsStartLocation[1] = new Point((cardBuffer[1].Location.X - 48) + handCardDistance, cardBuffer[1].Location.Y);
            cardBuffer[1].Location = new Point(120, 360);
            cardBuffer[1].AccessibleName = 12.ToString();
            GenerateCard(1);

            for (int j = 2; j < 5; j++)
            {
                handCardDistance += 48;
                int rnd = randomGlobal.Next(0, 12 + 1);
                cardBuffer[j].BackgroundImage = cardCounts[rnd].Item1;
                cardBuffer[j].Tag = cardCounts[rnd].Item2;
                handCardsStartLocation[j] = new Point((cardBuffer[j].Location.X - 48) + handCardDistance, cardBuffer[j].Location.Y);
                cardBuffer[j].Location = new Point(120, 360);
                await Task.Delay(20);
                GenerateCard(j);
                cardBuffer[j].AccessibleName = j.ToString();
                this.Controls.Add(cardBuffer[j]);
                zIndex[j] = this.Controls.GetChildIndex(cardBuffer[j]);
                await Task.Delay(20);
            }

        }


        private async void OnPictureBoxHauptStapelMouseDown(object sender, MouseEventArgs e)
        {
            /*if (!allowDrag)
            {
                return;
            }*/
            PictureBox currentPickedCard = (PictureBox)sender;
            this.Controls.Add(currentPickedCard);
            dragFlag = true;
            bool generatedCard = false;
            while (dragFlag)
            {
                Point tempPoint = PointToClient(Cursor.Position);
                currentPickedCard.Location = new Point(tempPoint.X - currentPickedCard.Width / 2, tempPoint.Y - currentPickedCard.Height / 2);
                if (currentPickedCard.Name == uiPictureBoxHauptStapel.Name && !generatedCard)
                {
                    generatedCard = true;
                }
                if (currentPickedCard.Bounds.IntersectsWith(uiPicBoxHauptAblageStapel.Bounds))
                {
                    uiPicBoxHauptAblageStapel.BackColor = Color.LightGreen;
                    currentPickedCard.BringToFront();
                }
                else
                {
                    uiPicBoxHauptAblageStapel.BackColor = Color.Transparent;
                }
                await Task.Delay(10);
            }
        }

        private void OnPictureBoxHauptStapelMouseUp(object sender, MouseEventArgs e)
        {
            PictureBox currentCardDrop = (PictureBox)sender;
            dragFlag = false;
            int cardTag = int.Parse(currentCardDrop.Tag.ToString());

            //int previousCardTag = currentCardNumber + cardTag;
            if (currentCardDrop.Bounds.IntersectsWith(uiPicBoxHauptAblageStapel.Bounds) && (ablageStapelCount[0] == cardTag || cardTag == 12))
            {
                currentCardDrop.Enabled = false;
                currentCardDrop.Visible = false;
                dragFlag = false;
                uiPicBoxHauptAblageStapel.BackgroundImage = currentCardDrop.BackgroundImage;

                if (cardTag == 12)
                {
                    cardTag = ablageStapelCount[0];
                    uiPicBoxHauptAblageStapel.BackgroundImage = cardCounts[cardTag].Item1;
                    ablageStapelCount[0]++;
                }
                else
                {
                    ablageStapelCount[0] = cardTag + 1;
                }

                if (!currentCardDrop.Visible)
                {
                    uiPictureBoxHauptStapel.Location = cardStartLocation;
                    uiPictureBoxHauptStapel.Visible = true;
                    uiPictureBoxHauptStapel.Enabled = true;
                    int mainCardStaple = randomGlobal.Next(0, 12 + 1);
                    uiPictureBoxHauptStapel.BackgroundImage = cardCounts[mainCardStaple].Item1;
                    uiPictureBoxHauptStapel.Tag = cardCounts[mainCardStaple].Item2;
                }
                //cardTag = 0;
                //cardTag += int.Parse(currentCardDrop.Tag.ToString());
                //currentCardDrop.Enabled = false;
                //currentCardDrop.Visible = false;
                //dragFlag = false;
                //uiPicBoxHauptAblageStapel.BackgroundImage = currentCardDrop.BackgroundImage;

                //if (!currentCardDrop.Visible)
                //{
                //    uiPictureBoxHauptStapel.Location = cardStartLocation;
                //    uiPictureBoxHauptStapel.Visible = true;
                //    uiPictureBoxHauptStapel.Enabled = true;
                //    int mainCardStaple = randomGlobal.Next(0, 12 + 1);
                //    uiPictureBoxHauptStapel.BackgroundImage = cardCounts[mainCardStaple].Item1;
                //    uiPictureBoxHauptStapel.Tag = cardCounts[mainCardStaple].Item2;
                //}
                //int.Parse(currentCardDrop.Tag.ToString());
            }
            //allowDrag = false;
            else
            {
                int accessName = int.Parse(currentCardDrop.AccessibleName);
                if (accessName >= 0 && accessName < 5)
                {
                    this.Controls.SetChildIndex(currentCardDrop, zIndex[accessName]);
                    currentCardDrop.Location = handCardsStartLocation[int.Parse(currentCardDrop.AccessibleName)];
                }
                else
                {
                    uiPictureBoxHauptStapel.Location = cardStartLocation;
                }
            }
        }

        private void OnMainDiscardPileMouseUp(object sender, MouseEventArgs e)
        {

        }
    }
}
