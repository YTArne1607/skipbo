﻿using SkipBo.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SkipBo
{
    public partial class uiFormSkipBo : Form
    {
        bool dragFlag = false;
        //bool allowDrag = true;
        Point cardStartLocation = new Point();
        int[] ablageStapelCount = new int[4];
        Tuple<Bitmap, int>[] cardCounts = new Tuple<Bitmap, int>[13];
        Control[] cardBuffer = new Control[60];
        Point[] handCardsStartLocation = new Point[5];
        Random randomGlobal = new Random();
        int[] zIndex = new int[56];
        int[] acceptedNumsInAblageStapel = new int[12];
        int currentCardNumber = 0;
        bool firstRun = true;
        PictureBox[] hauptAblageStapelCount = new PictureBox[4];
        Bitmap[] umgedrehteStapel = new Bitmap[4];

        int mainPile;


        public uiFormSkipBo()
        {
            InitializeComponent();

            mainPile = 20;
            cardStartLocation = uiPictureBoxHauptStapel.Location;

            for (int k = 0; k < 60; k++)
            {
                cardBuffer[k] = new PictureBox()
                {
                    Location = new Point(274, 360),
                    BackgroundImageLayout = ImageLayout.Zoom,
                    BackColor = Color.Transparent,
                    Size = new Size(60, 85)
                };

                cardBuffer[k].MouseDown += OnPictureBoxHauptStapelMouseDown;
                cardBuffer[k].MouseUp += OnPictureBoxHauptStapelMouseUp;

            }

            hauptAblageStapelCount[0] = uiPicBoxHauptAblageStapel;
            hauptAblageStapelCount[1] = uiPicBoxHauptAblageStapel0;
            hauptAblageStapelCount[2] = uiPicBoxHauptAblageStapel1;
            hauptAblageStapelCount[3] = uiPicBoxHauptAblageStapel2;

            umgedrehteStapel[0] = Properties.Resources._016;
            umgedrehteStapel[1] = Properties.Resources._013;
            umgedrehteStapel[2] = Properties.Resources._014;
            umgedrehteStapel[3] = Properties.Resources.Card_14;

            uiUmgedrehterStapel.BackgroundImage = umgedrehteStapel[0];
            uiUmgedrehterStapel.Size = new Size(82, 99);

            //uiPicBoxHauptAblageStapel.Name = hauptAblageStapelCount;

            CardSpread();

            int mainCardStaple = randomGlobal.Next(0, 12 + 1);
            uiPictureBoxHauptStapel.BackgroundImage = cardCounts[12].Item1;
            uiPictureBoxHauptStapel.Tag = cardCounts[12].Item2;

        }

        private async void GenerateCard(int startPosition)
        {
            while (cardBuffer[startPosition].Location.X < handCardsStartLocation[startPosition].X)
            {
                cardBuffer[startPosition].Location = new Point(cardBuffer[startPosition].Location.X + 12, cardBuffer[startPosition].Location.Y);
                await Task.Delay(10);
            }
        }
        private async void CardSpread()
        {

            for (int i = 0; i < 13; i++)
            {
                cardCounts[i] = new Tuple<Bitmap, int>(new Bitmap(Directory.GetCurrentDirectory() + "\\Resources\\Card " + (i + 1) + ".jpg"), i);
            }



            int handCardDistance = 0;
            //cardBuffer[0].BackgroundImage = cardCounts[0].Item1;
            //cardBuffer[0].Tag = cardCounts[0].Item2;
            //this.Controls.Add(cardBuffer[0]);
            //handCardsStartLocation[0] = new Point((cardBuffer[0].Location.X - 48) + handCardDistance, cardBuffer[0].Location.Y);
            //cardBuffer[0].Location = new Point(120, 360);
            //cardBuffer[0].AccessibleName = 0.ToString();
            //GenerateCard(0);

            //handCardDistance += 48;
            //cardBuffer[1].BackgroundImage = cardCounts[0].Item1;
            //cardBuffer[1].Tag = cardCounts[0].Item2;
            //this.Controls.Add(cardBuffer[1]);
            //handCardsStartLocation[1] = new Point((cardBuffer[1].Location.X - 48) + handCardDistance, cardBuffer[1].Location.Y);
            //cardBuffer[1].Location = new Point(120, 360);
            //cardBuffer[1].AccessibleName = 0.ToString();
            //GenerateCard(1);

            for (int j = 0; j < 5; j++)
            {
                handCardDistance += 48;
                int rnd = randomGlobal.Next(0, 12 + 1);
                cardBuffer[j].BackgroundImage = cardCounts[rnd].Item1;
                cardBuffer[j].Tag = cardCounts[rnd].Item2;
                handCardsStartLocation[j] = new Point((cardBuffer[j].Location.X - 48) + handCardDistance, cardBuffer[j].Location.Y);
                cardBuffer[j].Location = new Point(120, 360);
                await Task.Delay(20);
                GenerateCard(j);
                cardBuffer[j].AccessibleName = j.ToString();
                this.Controls.Add(cardBuffer[j]);
                zIndex[j] = this.Controls.GetChildIndex(cardBuffer[j]);
                await Task.Delay(20);
            }

        }


        private async void OnPictureBoxHauptStapelMouseDown(object sender, MouseEventArgs e)
        {
            /*if (!allowDrag)
            {
                return;
            }*/
            PictureBox currentPickedCard = (PictureBox)sender;
            this.Controls.Add(currentPickedCard);
            dragFlag = true;
            //bool generatedCard = false;

            while (dragFlag)
            {
                currentPickedCard.BringToFront();
                Point tempPoint = PointToClient(Cursor.Position);
                currentPickedCard.Location = new Point(tempPoint.X - currentPickedCard.Width / 2, tempPoint.Y - currentPickedCard.Height / 2);
                for (int j = 0; j < 4; j++)
                {
                    if (currentPickedCard.Bounds.IntersectsWith(hauptAblageStapelCount[j].Bounds))
                    {
                        hauptAblageStapelCount[j].BackColor = Color.FromArgb(100, Color.LimeGreen);
                    }
                    else
                    {
                        hauptAblageStapelCount[j].BackColor = Color.Transparent;
                    }
                }
                await Task.Delay(10);
            }
        }

        private void OnPictureBoxHauptStapelMouseUp(object sender, MouseEventArgs e)
        {
            PictureBox currentCardDrop = (PictureBox)sender;
            dragFlag = false;
            int cardTag = int.Parse(currentCardDrop.Tag.ToString());

            //int previousCardTag = currentCardNumber + cardTag;

            for (int j = 0; j < 4; j++)
            {
                hauptAblageStapelCount[j].BackColor = Color.Transparent;

                //for (int i = 0; i < ablageStapelCount.Length; i++)
                //{
                //hauptAblageStapelCount[j] = uiPicBoxHauptAblageStapel.Name += j;
                //stringToPicBox = this.Controls[hauptAblageStapelCount[j]] as PictureBox;

                if (currentCardDrop.Bounds.IntersectsWith(hauptAblageStapelCount[j].Bounds) && (ablageStapelCount[j] == cardTag || cardTag == 12))
                {
                    dragFlag = false;
                    hauptAblageStapelCount[j].BackgroundImage = currentCardDrop.BackgroundImage;

                    if (cardTag == 12)
                    {
                        cardTag = ablageStapelCount[j];
                        hauptAblageStapelCount[j].BackgroundImage = cardCounts[cardTag].Item1;
                        ablageStapelCount[j]++;
                    }
                    else
                    {
                        ablageStapelCount[j] = cardTag + 1;
                    }

                    mainPile--;

                    uiPictureBoxHauptStapel.Location = cardStartLocation;

                    int mainCardStaple = randomGlobal.Next(0, 12 + 1);
                    uiPictureBoxHauptStapel.BackgroundImage = cardCounts[12].Item1;
                    uiPictureBoxHauptStapel.Tag = cardCounts[12].Item2;

                    //for (int k = 20; k >= 0; k--)
                    //{

                    //    uiUmgedrehterStapel.Size = new Size(60, 85);

                    //    if (!currentCardDrop.Visible)
                    //    {
                    //        uiPictureBoxHauptStapel.Location = cardStartLocation;
                    //        uiPictureBoxHauptStapel.Visible = true;
                    //        uiPictureBoxHauptStapel.Enabled = true;
                    //        int mainCardStaple = randomGlobal.Next(0, 12 + 1);
                    //        uiPictureBoxHauptStapel.BackgroundImage = cardCounts[12].Item1;
                    //        uiPictureBoxHauptStapel.Tag = cardCounts[12].Item2;
                    //        k--;

                    if (mainPile >= 13 && mainPile <= 20)
                    {
                        uiUmgedrehterStapel.Size = new Size(82, 99);
                        uiUmgedrehterStapel.BackgroundImage = umgedrehteStapel[0];
                    }
                    else if (mainPile >= 6 && mainPile < 13)
                    {
                        uiUmgedrehterStapel.Size = new Size(82, 99);
                        uiUmgedrehterStapel.BackgroundImage = umgedrehteStapel[1];
                    }
                    else if (mainPile >= 1 && mainPile < 6)
                    {
                        uiUmgedrehterStapel.Size = new Size(82, 99);
                        uiUmgedrehterStapel.BackgroundImage = umgedrehteStapel[2];
                    }
                    else
                    {
                        uiUmgedrehterStapel.BackgroundImage = null;
                        uiUmgedrehterStapel.BackColor = Color.White;
                    }
                    //    }


                }
                //allowDrag = false;
                else if (j == 3)
                {
                    // Wenn karte ausserhalb der Hauptablagestapel abgelegt wird. Zurück auf CardStartLocation
                    int accessName = int.Parse(currentCardDrop.AccessibleName);
                    if (accessName >= 0 && accessName < 5)
                    {
                        this.Controls.SetChildIndex(currentCardDrop, zIndex[accessName]);
                        currentCardDrop.Location = handCardsStartLocation[int.Parse(currentCardDrop.AccessibleName)];
                    }
                    else
                    {
                        uiPictureBoxHauptStapel.Location = cardStartLocation;
                    }
                }
            }
        }


        private void OnMainDiscardPileMouseUp(object sender, MouseEventArgs e)
        {

        }
    }
}
