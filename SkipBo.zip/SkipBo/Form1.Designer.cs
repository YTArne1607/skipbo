﻿namespace SkipBo
{
    partial class uiFormSkipBo
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(uiFormSkipBo));
            this.uiPictureBoxHauptStapel = new System.Windows.Forms.PictureBox();
            this.uiPicBoxHauptAblageStapel = new System.Windows.Forms.PictureBox();
            this.uiPicBoxHauptAblageStapel0 = new System.Windows.Forms.PictureBox();
            this.uiPicBoxHauptAblageStapel1 = new System.Windows.Forms.PictureBox();
            this.uiPicBoxHauptAblageStapel2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.uiUmgedrehterStapel = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.uiPictureBoxHauptStapel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiPicBoxHauptAblageStapel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiPicBoxHauptAblageStapel0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiPicBoxHauptAblageStapel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiPicBoxHauptAblageStapel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiUmgedrehterStapel)).BeginInit();
            this.SuspendLayout();
            // 
            // uiPictureBoxHauptStapel
            // 
            this.uiPictureBoxHauptStapel.AccessibleName = "9";
            this.uiPictureBoxHauptStapel.BackColor = System.Drawing.Color.Transparent;
            this.uiPictureBoxHauptStapel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.uiPictureBoxHauptStapel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiPictureBoxHauptStapel.Location = new System.Drawing.Point(127, 362);
            this.uiPictureBoxHauptStapel.Name = "uiPictureBoxHauptStapel";
            this.uiPictureBoxHauptStapel.Size = new System.Drawing.Size(60, 85);
            this.uiPictureBoxHauptStapel.TabIndex = 1;
            this.uiPictureBoxHauptStapel.TabStop = false;
            this.uiPictureBoxHauptStapel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.OnPictureBoxHauptStapelMouseDown);
            this.uiPictureBoxHauptStapel.MouseUp += new System.Windows.Forms.MouseEventHandler(this.OnPictureBoxHauptStapelMouseUp);
            // 
            // uiPicBoxHauptAblageStapel
            // 
            this.uiPicBoxHauptAblageStapel.BackColor = System.Drawing.Color.Transparent;
            this.uiPicBoxHauptAblageStapel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.uiPicBoxHauptAblageStapel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiPicBoxHauptAblageStapel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiPicBoxHauptAblageStapel.Location = new System.Drawing.Point(240, 159);
            this.uiPicBoxHauptAblageStapel.Name = "uiPicBoxHauptAblageStapel";
            this.uiPicBoxHauptAblageStapel.Size = new System.Drawing.Size(59, 84);
            this.uiPicBoxHauptAblageStapel.TabIndex = 2;
            this.uiPicBoxHauptAblageStapel.TabStop = false;
            this.uiPicBoxHauptAblageStapel.MouseUp += new System.Windows.Forms.MouseEventHandler(this.OnMainDiscardPileMouseUp);
            // 
            // uiPicBoxHauptAblageStapel0
            // 
            this.uiPicBoxHauptAblageStapel0.BackColor = System.Drawing.Color.Transparent;
            this.uiPicBoxHauptAblageStapel0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.uiPicBoxHauptAblageStapel0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiPicBoxHauptAblageStapel0.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiPicBoxHauptAblageStapel0.Location = new System.Drawing.Point(326, 159);
            this.uiPicBoxHauptAblageStapel0.Name = "uiPicBoxHauptAblageStapel0";
            this.uiPicBoxHauptAblageStapel0.Size = new System.Drawing.Size(59, 84);
            this.uiPicBoxHauptAblageStapel0.TabIndex = 3;
            this.uiPicBoxHauptAblageStapel0.TabStop = false;
            // 
            // uiPicBoxHauptAblageStapel1
            // 
            this.uiPicBoxHauptAblageStapel1.BackColor = System.Drawing.Color.Transparent;
            this.uiPicBoxHauptAblageStapel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.uiPicBoxHauptAblageStapel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiPicBoxHauptAblageStapel1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiPicBoxHauptAblageStapel1.Location = new System.Drawing.Point(413, 159);
            this.uiPicBoxHauptAblageStapel1.Name = "uiPicBoxHauptAblageStapel1";
            this.uiPicBoxHauptAblageStapel1.Size = new System.Drawing.Size(59, 84);
            this.uiPicBoxHauptAblageStapel1.TabIndex = 4;
            this.uiPicBoxHauptAblageStapel1.TabStop = false;
            // 
            // uiPicBoxHauptAblageStapel2
            // 
            this.uiPicBoxHauptAblageStapel2.BackColor = System.Drawing.Color.Transparent;
            this.uiPicBoxHauptAblageStapel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.uiPicBoxHauptAblageStapel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiPicBoxHauptAblageStapel2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiPicBoxHauptAblageStapel2.Location = new System.Drawing.Point(500, 159);
            this.uiPicBoxHauptAblageStapel2.Name = "uiPicBoxHauptAblageStapel2";
            this.uiPicBoxHauptAblageStapel2.Size = new System.Drawing.Size(59, 84);
            this.uiPicBoxHauptAblageStapel2.TabIndex = 5;
            this.uiPicBoxHauptAblageStapel2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Location = new System.Drawing.Point(240, 277);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(59, 84);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox5.Location = new System.Drawing.Point(326, 277);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(59, 84);
            this.pictureBox5.TabIndex = 7;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox6.Location = new System.Drawing.Point(413, 277);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(59, 84);
            this.pictureBox6.TabIndex = 8;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox7.Location = new System.Drawing.Point(500, 277);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(59, 84);
            this.pictureBox7.TabIndex = 9;
            this.pictureBox7.TabStop = false;
            // 
            // uiUmgedrehterStapel
            // 
            this.uiUmgedrehterStapel.AccessibleName = "9";
            this.uiUmgedrehterStapel.BackColor = System.Drawing.Color.Transparent;
            this.uiUmgedrehterStapel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.uiUmgedrehterStapel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiUmgedrehterStapel.Location = new System.Drawing.Point(116, 353);
            this.uiUmgedrehterStapel.Name = "uiUmgedrehterStapel";
            this.uiUmgedrehterStapel.Size = new System.Drawing.Size(60, 85);
            this.uiUmgedrehterStapel.TabIndex = 10;
            this.uiUmgedrehterStapel.TabStop = false;
            // 
            // uiFormSkipBo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SkipBo.Properties.Resources.luxa_org_opacity_changed___Skipbo_background;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.uiPictureBoxHauptStapel);
            this.Controls.Add(this.uiPicBoxHauptAblageStapel);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.uiPicBoxHauptAblageStapel0);
            this.Controls.Add(this.uiPicBoxHauptAblageStapel1);
            this.Controls.Add(this.uiPicBoxHauptAblageStapel2);
            this.Controls.Add(this.uiUmgedrehterStapel);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "uiFormSkipBo";
            this.Text = "SkipBo";
            ((System.ComponentModel.ISupportInitialize)(this.uiPictureBoxHauptStapel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiPicBoxHauptAblageStapel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiPicBoxHauptAblageStapel0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiPicBoxHauptAblageStapel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiPicBoxHauptAblageStapel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiUmgedrehterStapel)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox uiPictureBoxHauptStapel;
        private System.Windows.Forms.PictureBox uiPicBoxHauptAblageStapel;
        private System.Windows.Forms.PictureBox uiPicBoxHauptAblageStapel0;
        private System.Windows.Forms.PictureBox uiPicBoxHauptAblageStapel1;
        private System.Windows.Forms.PictureBox uiPicBoxHauptAblageStapel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox uiUmgedrehterStapel;
    }
}

